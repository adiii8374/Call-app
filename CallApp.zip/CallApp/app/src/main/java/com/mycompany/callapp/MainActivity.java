package com.mycompany.callapp;

import android.app.*;
import android.os.*;
import android.widget.*;
import android.content.*;
import android.view.*;
import android.net.*;

public class MainActivity extends Activity 
{
	EditText et;
	
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		et=(EditText)findViewById(R.id.mainEditText);
    }
	public void call(View v) {
		String st=et.getText().toString();
		Intent in=new Intent(Intent.ACTION_CALL,Uri.parse("tel:"+st));
		startActivity(in);
	}
}
